from django.apps import AppConfig


class ManagementConfig(AppConfig):
    name = 'management'
