from django.db import models
from django.contrib.auth.models import User
# Create your models here.

# class UserManager():
#     def get_queryset(self):
#         return super(UserManager, self).get_queryset().filter(isDelete=False)

class MyUser(models.Model):
    # 自定义模型管理器
   # userObj = UserManager()
    # 用系统django里的User
    user = models.OneToOneField(User)
    # 自己设计的属性
    nickname = models.CharField(max_length=16)
    gender = models.BooleanField(default=False)
    permission = models.IntegerField(default=0)
    isDelete = models.BooleanField(default=False)

    # 创建一个用户
    # @classmethod
    # def createUser(cls, name, nickname, gender, age, permission, isDel=False):
    #     user = cls(uname=name, unckname=nickname, ugender=gender, uage=age, upermission=permission, isDelete=isDel)
    #     return user

    def __str__(self):
        return self.user.username
        # 定义元信息
    class Meta:
        db_table = "users"  # 表的名字
        ordering = ["id"]  # 表的外键升序 #["-id"]降序

class Book(models.Model):
    @classmethod
    def addBook(cls, bimage, bauthor, bpublisher, btitle, btranslator, bpubdate, bpages, bprice, bbinding, bisbn, bcategory, bnumber, isDel=False):
        books = cls(
                image=bimage,
                author=bauthor,
                publisher=bpublisher,
                title=btitle,
                translator=btranslator,
                pubdate=bpubdate,
                pages=bpages,
                price=bprice,
                binding=bbinding,
                isbn=bisbn,
                category=bcategory,
                bnumber=bnumber,
                isDelete=isDel
            )
        return books
    image = models.CharField(max_length=128)
    author = models.CharField(max_length=128)
    publisher = models.CharField(max_length=128)
    title = models.CharField(max_length=128)
    translator = models.CharField(max_length=128)
    pubdate = models.DateField()
    pages = models.IntegerField()
    price = models.FloatField()
    binding = models.CharField(max_length=128)
    isbn = models.CharField(max_length=13)
    category = models.ForeignKey("Category")
    bnumber = models.IntegerField() #现在库存中还剩多少本书
    sellnumber = models.IntegerField(default=0) #卖出了多少本
    isDelete = models.BooleanField(default=False)

    class Meta:
        db_table = "book"  # 表的名字
        ordering = ["id"]  # 表的外键升序 #["-id"]降序

    def __str__(self):
        return self.title
# 书店类型
class Category(models.Model):
    category = models.CharField(max_length=128)
    cnumber = models.IntegerField()
    isDelete = models.BooleanField(default=False)

    def addCategory(cls, ccategory, ccnumber, isDel=False):
        updatecategory = cls(
            category = ccategory,
            cnumber = ccnumber,
            isDelete=isDel
        )
        return updatecategory

    class Meta:
        db_table = "category"  # 表的名字
        ordering = ["id"]  # 表的外键升序 #["-id"]降序

    def __str__(self):
        return self.category