from django.test import TestCase

# Create your tests here.
import time,datetime
# date to str
print(time.localtime())
print(time.strftime("%Y-%m-%d %X", time.localtime()))
#str to date
t = time.strptime("2009 - 08 - 08", "%Y - %m - %d")
y,m,d = t[0:3]
print(datetime.datetime(y,m,d))