from django.shortcuts import render
from django.core.urlresolvers import reverse
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth.models import User
from django.contrib import auth
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.urlresolvers import reverse
from django.utils import *
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import user_passes_test
import time,datetime,string,re
from django.http import JsonResponse
from django.http import HttpResponseRedirect
from .models import MyUser
from .models import Book, Category

# 首页
def index(request):
     user = request.user if request.user.is_authenticated() else None
     content = {
         'active_menu': 'homepage',
         'user': user,
     }
     # 测试
     #return HttpResponse("这是我的毕业设计")
     return render(request, 'management/index.html',content)

# 注册
def signup(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect(reverse('management:homepage'))
    state = None

    if request.method == 'POST':
        password = request.POST.get('password', '')
        repeat_password = request.POST.get('repeat_password', '')
        if password == '' or repeat_password == '':
            state = 'empty'
        elif password != repeat_password:
            state = 'repeat_error'
        else:
            username = request.POST.get('username', '')
            if User.objects.filter(username=username):
                state = 'user_exist'
            else:
                # nickname = models.CharField(max_length=16)
                # gender = models.BooleanField(default=False)
                # age = models.IntegerField()
                # permission = models.IntegerField(default=1)
                # isDelete = models.BooleanField(default=False)

                unickname = request.POST.get('nickname', '')
                ugender = request.POST.get('gender', '')
                isDelete = False

                new_user = User.objects.create_user(username=username, password=password, email=request.POST.get('email', ''))
                new_user.save()
                new_my_user = MyUser(user=new_user, nickname=unickname, gender=ugender, isDelete=False)
                new_my_user.save()
                state = 'success'

    content = {
        'active_menu': 'homepage',
        'state': state,
        'user': None,
    }
    return render(request, 'management/signup.html', content)

# 登录
def login(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect(reverse('management:homepage'))
        #return reverse('index')
    state = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return HttpResponseRedirect(reverse('management:homepage'))
            #return reverse('index')
        else:
            state = 'not_exist_or_password_error'
    content = {
        'active_menu': 'homepage',
        'state': state,
        'user': None
    }
    return render(request, 'management/login.html', content)

def logout(request):
    auth.logout(request)
    return HttpResponseRedirect(reverse('management:homepage'))

@login_required
def add_book(request):
    #test1 = request.POST.get('image', '')
    #print(test1)
    # print(test2)
    user = request.user
    state = None
    if request.method == 'POST':
        # 从数据库中取出要添加的书的类别
        image = request.POST.get('image', ''),
        author = request.POST.get('author', ''),
        publisher = request.POST.get('publisher', ''),
        title = request.POST.get('title', ''),
        translator = request.POST.get('translator', ''),
        pubdate = request.POST.get('pubdate', ''),
        pages = request.POST.get('pages', ''),
        price = request.POST.get('price', ''),
        binding = request.POST.get('binding', ''),
        isbn = request.POST.get('isbn', ''),
        bcategory = request.POST.get('bcatagory', '')
        bnumber = request.POST.get('bnumber', ''),

        print(bcategory)
        #print(type(bcategory))
        # 由于上面测试，取回的value数据时一个str型，要转化成int型
        #t = time.strptime("pubdate", "%Y-%m-%d")
        #y, m, d = t[0:3]
        #pubdate = datetime.datetime(y, m, d) #2016-8-1
        #print(pages)       ('124',)
        #print(pages[0])    (124)
        #print(type(pages[0])) (<calss 'str'>)
        image = image[0]
        author = author[0]
        publisher = publisher[0]
        title = title[0]
        translator = translator[0]
        pages = int(pages[0])  # 将str类型转换成int类型
        # print(price[0][:-1]) # 将25.80元 截取25.80
        price = float(price[0][:-1])
        binding = binding[0]
        isbn = isbn[0]
        bcategory = int(bcategory)
        bnumber = int(bnumber[0])
        pubdate = pubdate[0]
        #print(pubdate)

        # 查询某个书的类型
        #image, author, publisher, title, translator, pubdate, pages, price, binding, isbn, bcategory, bnumber, isDel = False
        # 将添加的书的数目的  类型数目 顺便也添加到category的cnumber上，实现累加
        # 通过在书中查找isbn号，如果没有相同的isbn号，则将该书的类型的从cnumber属性增加1
        category = Category.objects.get(pk=bcategory)
        # 找出这个类里面的所有书籍 Person.objects.filter(name__contains="abc").update(name='xxx') # 名称中包含 "abc"的人 都改成 xxx
        bookList = category.book_set.all()
        print(bookList)
        flag = True
        for book in bookList:
            print(book.isbn)
            if(isbn == book.isbn):
                # 如果相等，更新book表里的bnumber
                 num = book.bnumber + bnumber
                # 因为不能链式查询，所有只好重新查找了，既然通过filter直接找到那本书了，也不必用for循环了，不会这样加快了查找的效率了，因为书缩写了，且就这一本
                 Book.objects.filter(isbn__contains=book.isbn).update(bnumber=num)
                 print(book.isbn+"-------"+ str(book.bnumber))
                 flag = False

        category.save()

        # 如果都不想等，将这个书添加到book里面，将category.cnumber增加1
        if(flag == True):
            new_book = Book.addBook(image, author, publisher, title, translator, pubdate, pages, price, binding, isbn, category, bnumber)
            category.cnumber = category.cnumber + 1
            new_book.save()
            category.save()

        state = 'success'
    content = {
                'user': user,
                'active_menu': 'add_book',
                'state': state,
            }
    return render(request, 'management/add_book.html', content)
       # return render(request, 'management/add_book.html')

# ajax例子
@login_required
def sell_book(request):

    if not request.user.is_authenticated():
        content = {
                'active_menu': 'homepage'
            }
        return HttpResponseRedirect(reverse('management:homepage'))
    else:
        content = {
                'active_menu': 'sell_book'
            }
        return render(request, 'management/sell_book.html', content)
#获取书籍信息
import json
def book_detail(request):
    print("测试")
    if request.method == 'POST':
        bisbn = request.POST.get("isbn","")
        buynumber = request.POST.get("buynumber","")
        print("买书的数量: "+buynumber)
        buynumber = int(buynumber)
        print(bisbn)
        print(type(bisbn))
        print(type(buynumber))

        book = Book.objects.get(isbn=bisbn)
        # 书籍取出后，要修改book表中的bnumber值，将其更新（减少1本书）
        book.bnumber = book.bnumber - buynumber;
        book.sellnumber = book.sellnumber + buynumber;
        book.save()

        print(type(book))
        #booklist = []
        #booklist = [book.image, book.author, book.category.category, book.pubdate, book.price, book.sellnumber]
        print(type(book.price))
        # 这里要设置一下float的精确度，否则，当通过Json传递到js中转换成字符串时，会出现14位的小数335.40000000000003
        # priceTemp = book.price
        # price = round(book.price, 2)
        # print(price)
        bookdict = {"image":book.image, "title":book.title, "author":book.author, "category":book.category.category, "pubdate":book.pubdate, "price":book.price}
        #print(booklist)
        print(type(bookdict))
        print(bookdict)
    return JsonResponse({"data": bookdict})

# 重置密码
def set_password(request):
    user = request.user
    state = None
    if request.method == 'POST':
        old_password = request.POST.get('old_password', '')
        new_password = request.POST.get('new_password', '')
        repeat_password = request.POST.get('repeat_password', '')
        if user.check_password(old_password):
            if not new_password:
                state = 'empty'
            elif new_password != repeat_password:
                state = 'repeat_error'
            else:
                user.set_password(new_password)
                user.save()
                state = 'success'
        else:
            state = 'password_error'
    content = {
        'user': user,
        'active_menu': 'homepage',
        'state': state,
    }
    return render(request, 'management/set_password.html', content)

@login_required
def trend_book(request):
    bookcategory = []
    booktype = []

    #提取每类书籍的销售量
    for num in range(1,6):
        try:
            category = Category.objects.get(pk=num)# 书的类别：文学， 文化， 生活， 经管， 科技
        except Exception as e:
            pass

        print(category.category)
        bookcategory.append(category.category)

        bookList = category.book_set.all()  #找到书类别下的所有书
        perSum = 0
        for onetype in bookList:     # 从所有书中提取出,卖这本书的数目
             perSum = perSum + onetype.sellnumber
             perPrice = perSum * onetype.price
        booktype.append(perSum)
        print(perSum)

    print(bookcategory)
    print(booktype)
    sellcontent = {
        'bookcategory': json.dumps(bookcategory), 
        'booktype': json.dumps(booktype),
        'active_menu': 'trend_book'
        }

    return render(request, 'management/trend_book.html',sellcontent)
