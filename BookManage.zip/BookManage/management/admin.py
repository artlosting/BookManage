from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from management.models import *

class MyUserInline(admin.StackedInline):
    model = MyUser
    can_delete = False

class UserAdmin(BaseUserAdmin):
    inlines = (MyUserInline,)

class BooksInfor(admin.TabularInline):
    model = Book
    extra = 0

class CategoryAdmin(admin.ModelAdmin):
    inlines = [BooksInfor]
    actions_on_bottom = False
    actions_on_top = True
    #列表页属性
    list_display = ['pk','category','cnumber','isDelete']
    list_per_page = 10

class BookAdmin(admin.ModelAdmin):

   # title.short_description = "书名"
    actions_on_bottom = False
    actions_on_top = True
    #列表页属性
    list_display = ['pk',  'sellnumber', 'title', 'author', 'publisher','translator', 'pubdate', 'pages', 'price', 'binding', 'isbn', 'category', 'bnumber', 'image']
    list_per_page = 10

admin.site.site_header = '实体书店销售管理系统'
admin.site.site_title = '实体书店销售管理系统'
admin.site.unregister(User)
admin.site.register(User, UserAdmin)
admin.site.register(Book,BookAdmin)
admin.site.register(Category,CategoryAdmin)