$(document).ready(function(){
    console.log("000000000000000000000000")
        $("#search").click(function(){
             console.log("111111111111111111111111111111");
            var isbn = $('#id_isbn').val();
            //var isbn = $(" input[ name='isbn' ] ").val();
            console.log(isbn);
            $.ajax({
                type:'post',
                url:"https://api.douban.com/v2/book/isbn/:"+isbn,
                dataType:'jsonp',
                crossDomain: true,
                success:function(data,status){
                    console.log(data)
                 // 将图片路径存在id_image的value里，虽然是隐藏的，但方便通过POST提交数据
                   $("#id_image").val(data.image);
                   $("#id_title").val(data.title);
                   $("#id_publisher").val(data.publisher);
                   $("#id_author").val(data.author);
                   $("#id_title").val(data.title);
                  if(data.translator != ""){
                        $("#id_translator").val(data.translator);
                  } else {
                         $("#id_translator").val("暂无");
                  }
                   $("#id_pubdate").val(data.pubdate);
                   $("#id_pages").val(data.pages);
                   $("#id_price").val(data.price);
                   $("#id_binding").val(data.binding);

                }
            });

        })
})

//$(document).ready(function(){
//    console.log("000000000000000000000000")
//    document.getElementById("search").onclick = function(){
//        console.log("111111111111111111111111111111");
//        var isbn = $('#id_isbn').val();
//        //var isbn = $(" input[ name='isbn' ] ").val();
//        console.log(isbn);
//         $.ajax({
//                    type: "post",//数据发送的方式（post 或者 get）
//                    url: "",//要发送的后台地址
//                    data: {val1:"1",val2:"2"},//要发送的数据（参数）格式为{'val1':"1","val2":"2"}
//                    dataType: "json",//后台处理后返回的数据格式
//                    success: function (data) {//ajax请求成功后触发的方法
//                       alert('请求成功');
//                    },
//                    error: function (msg) {//ajax请求失败后触发的方法
//                        alert(msg);//弹出错误信息
//                    }
//         });
//    }
//})