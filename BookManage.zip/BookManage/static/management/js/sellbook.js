var total = 0;
$(document).ready(function(){
    var n = 0;
    var buynumber = 0;
    console.log("It is testing this sellbook.js");
    $("#sell").click(function(){
        var isbn_data = $("input[name='isbn']").val();

        var buynumber_data = $("input[name='buynumber']").val();
        buynumber =  parseInt(buynumber_data);
        console.log("书的数目："+buynumber);
        console.log(typeof(isbn_data));
        console.log(typeof(buynumber_data));
        console.log(typeof(buynumber));


        if(isbn_data.length != 13) {
            alert("输入的isbn有误！请输入正确的isbn号");
        }else {
            var post_data = {"isbn": isbn_data,"buynumber": buynumber};
            console.log("测试，isbn号符合13位的，开始通过isbn号请求数据库中的数据")

            $.ajax({
                type: "POST",
                data: post_data,
                url: "/sell_book/book_detail/",
                //dataType:"json",{book.image, book.author, book.category.category, book.pubdate, book.price}
                success:function(data, status){
                    //data 是一个字典
                    console.log(data);
                    var book = data["data"]; //去掉{ }，剩下的是一个二维数组，第一层是一本书，第二次是书的信息
                     //alert(book['author']); //已经拿到数据了
                     //alert(book['image'])
//                     imgurl = book['image'];
//                     // 这一点，我想写一个函数来请求得到的image的url，否则下面生成的图片链接，在网页上加载不出来。因为虽然生成了图片
//                     //图片链接，但没有请求那个图片
//                     //fimg(imgurl);
                     //alert(typeof(fimg(imgurl)));
                    n = buynumber + n; // 通过将上次的要买的number值保存到全局变量n中，然后当再次买的书的数目时，继续加到n变量上。
                    total = n * book.price; //只要浏览器不刷新，将总共买的n的数目乘以书的价格，得到中共价钱。
                    totalPrice = ruturnFloat(total)
                    console.log(totalPrice)
                    $("#totalPrice").html(totalPrice+"元");
                    $("#bookInfor").prepend("<div class='borderline' border='1px solid red'><div class='col-md-6' data-ride='carousel'><img width='100px' margin-top='20px' margin-left='80px' src="+book['image']+"></div><div class='col-md-4 col-md-offset-1'><h4>书名："+book['title']+"</h4><h4>作者："+book['author']+"</h4><h4>类别："+book['category']+"</h4><h4>出版日期："+book['pubdate']+"</h4><h4>价格："+book['price']+"元</h4></div></div>");
                  }
             })
        }
    }
    );
})
function ruturnFloat(value){
     var value=Math.round(value*100)/100;
     var xsd=value.toString().split("."); //xsd是一个数组
     if(xsd.length==1){
         value=value.toString()+".0";
         return value;
     }
     if(xsd.length>1){//小数部分
         if(xsd[1].length<2){
            value=value.toString();
         }
         return value;
         }
}